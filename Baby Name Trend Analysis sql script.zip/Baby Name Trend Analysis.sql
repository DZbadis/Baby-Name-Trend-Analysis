/*
Objective 1
Track changes in name popularity
Your first objective is to see how the most popular names have changed over time,
and also to identify the names that have jumped the most in terms of popularity.
*/

-- Find the overall most popular girl and boy names and show how they have changed in popularity rankings over the years

WITH names_rank AS(SELECT *,DENSE_RANK() OVER( PARTITION BY Gender ORDER BY total_births DESC) AS name_rnk
FROM(
  
SELECT Name,Gender,SUM(Births) AS total_births
FROM names
GROUP BY Name,Gender) AS t),

overall_most_popularname AS(SELECT Name,Gender
FROM names_rank
WHERE name_rnk=1),

over_year_namesrnk AS(
SELECT *,DENSE_RANK() OVER( PARTITION BY Gender,Year ORDER BY total_births DESC) AS name_rnk
FROM

(SELECT Name,Gender,Year,SUM(Births) AS total_births
FROM names
GROUP BY Name,Gender,Year)AS t)


SELECT o.Name,o.Gender,Year,name_rnk
FROM over_year_namesrnk oy
JOIN overall_most_popularname o
ON oy.Name=o.Name
AND oy.Gender=o.Gender


-- the result of the above query shows a decline in 'Jessica' name popularity starting from 1998
-- where Michael name has also slightly declined

/*
Find the names with the biggest jumps in popularity from the first year of the data set to the last year
*/

SELECT MIN(Year)__1980,MAX(Year)__2009
FROM names

WITH first_year_rank AS(
SELECT Name,ROW_NUMBER() OVER(ORDER BY total_births DESC) AS first_year_rnk
FROM(
SELECT Name,SUM(Births) AS total_births
FROM names
WHERE Year=1980
GROUP BY Name) AS t),

last_year_rank AS(
SELECT Name,ROW_NUMBER() OVER(ORDER BY total_births DESC) AS last_year_rnk
FROM(
SELECT Name,SUM(Births) AS total_births
FROM names
WHERE Year=2009
GROUP BY Name) AS t)

SELECT Name,first_year_rnk,last_year_rnk
FROM(
SELECT f.Name,first_year_rnk,last_year_rnk,CAST(last_year_rnk AS SIGNED)-CAST(first_year_rnk AS SIGNED) AS rank_difference
FROM first_year_rank f
JOIN last_year_rank l
ON f.Name=l.Name) AS t
ORDER BY rank_difference



/*
Objective 2
Compare popularity across decades
Your second objective is to find the top 3 girl names and top 3 boy names for each year, and also for each decade.
*/

-- For each year, return the 3 most popular girl names and 3 most popular boy names

WITH girls_names AS(SELECT *,ROW_NUMBER() OVER(PARTITION BY Year ORDER BY total_births DESC) AS popularity
FROM(
SELECT Name,Year,SUM(Births) AS total_births
FROM names
WHERE Gender='F'
GROUP BY Name,Year) AS t),

top_girls_names AS(
SELECT Name,Year
FROM girls_names
WHERE popularity <=3),-- this query returns the top 3 girls names for each year
  
boys_names AS(
SELECT *,ROW_NUMBER() OVER(PARTITION BY Year ORDER BY total_births DESC) AS popularity
FROM(
SELECT Name,Year,SUM(Births) AS total_births
FROM names
WHERE Gender='M'
GROUP BY Name,Year) AS t),

top_boys_names AS(
SELECT Name,Year
FROM boys_names
WHERE popularity <=3 -- this query returns the top 3 boys names for each year
)



-- For each decade, return the 3 most popular girl names and 3 most popular boy names

WITH girls_names AS(SELECT *,ROW_NUMBER() OVER(PARTITION BY decade ORDER BY total_births DESC) AS pop
FROM(
SELECT FLOOR(Year/10)*10 AS decade,Name,SUM(Births)AS total_births
FROM names
WHERE Gender='F'
GROUP BY decade,Name) AS t),

top_girls_pop AS(SELECT decade,Name,pop
FROM girls_names
WHERE pop<=3) -- this query returns top 3 female names for each decade
,

boys_names AS(SELECT *,ROW_NUMBER() OVER(PARTITION BY decade ORDER BY total_births DESC) AS pop
FROM(
SELECT FLOOR(Year/10)*10 AS decade,Name,SUM(Births)AS total_births
FROM names
WHERE Gender='M'
GROUP BY decade,Name) AS t),

top_boys_pop AS(SELECT decade,Name,pop
FROM boys_names
WHERE pop<=3)-- this query returns top 3 males names for each decade


/*
Objective 3
Compare popularity across regions
Your third objective is to find the number of babies born in each region, 
and also return the top 3 girl names and top 3 boy names within each region.
*/

-- Return the number of babies born in each of the six regions (NOTE: The state of MI should be in the Midwest region)

SELECT region,SUM(total_births) AS total_births
FROM(
SELECT COALESCE(r.Region,'Midwest')AS region,SUM(n.Births) AS total_births
FROM names n
LEFT JOIN regions r
ON n.State=r.State
GROUP BY r.Region) AS t
GROUP BY region
ORDER BY total_births DESC

-- Return the 3 most popular girl names and 3 most popular boy names within each region
WITH region_births AS(
SELECT region,Gender,Name,SUM(total_births) AS total_births
FROM(
SELECT COALESCE(r.region,'Midwest')AS region,Gender,Name,SUM(Births) AS total_births
FROM names n
LEFT JOIN regions r
ON n.State=r.State 
GROUP BY r.region,Gender,Name)AS t
GROUP BY region,Gender,Name)

SELECT *
FROM(
SELECT region,Gender,Name,total_births,ROW_NUMBER() OVER(PARTITION BY region,Gender ORDER BY total_births DESC) AS name_rnk
FROM region_births) AS t
WHERE name_rnk <=3


/*
Objective 4
Explore unique names in the dataset
Your final objective is to find the most popular androgynous names, 
the shortest and longest names, and the state with the highest percent of babies named "Chris".
*/

-- Find the 10 most popular androgynous names (names given to both females and males)


WITH female_names AS(SELECT DISTINCT Name 
FROM names
WHERE Gender='F'
GROUP BY Name)
,
males_names AS(SELECT DISTINCT Name
FROM names
WHERE Gender='M'),

androgynous AS(
SELECT m.Name AS androgynous
FROM males_names m
JOIN female_names f
ON m.Name=f.Name)

SELECT *
FROM(
SELECT Name,SUM(Births) AS total_births,ROW_NUMBER() OVER(ORDER BY SUM(Births) DESC) AS name_rnk
FROM names
WHERE Name IN(SELECT androgynous FROM androgynous)
GROUP BY Name) AS t
WHERE name_rnk <=10

-- Find the length of the shortest and longest names, and identify the most popular short names 
-- (those with the fewest characters) and long names (those with the most characters)

WITH names_length AS(
SELECT DISTINCT Name,LENGTH(Name) AS name_lenghth,DENSE_RANK() OVER(ORDER BY LENGTH(Name) DESC) AS long_name_rnk,
DENSE_RANK() OVER(ORDER BY LENGTH(Name) ASC) AS shor_name_rnk 
FROM names),

short_names_pop AS(
SELECT *
  FROM(
SELECT Name,SUM(Births) AS total_births,ROW_NUMBER() OVER(ORDER BY SUM(Births) DESC) AS pop_rnk
FROM names
WHERE Name IN(SELECT DISTINCT Name FROM names_length WHERE shor_name_rnk=1)
GROUP BY Name)AS t  
WHERE pop_rnk =1) -- this query will return top popular short names

SELECT *
FROM(
SELECT Name,SUM(Births) AS total_births,ROW_NUMBER() OVER(ORDER BY SUM(Births) DESC) AS pop_rnk
FROM names
WHERE Name IN(SELECT DISTINCT Name FROM names_length WHERE long_name_rnk=1)
GROUP BY Name) AS t
WHERE pop_rnk=1 -- this query returns the most popular longest name

-- The founder of Maven Analytics is named Chris. Find the state with the highest percent of babies named "Chris"

WITH chris_names AS(SELECT State,SUM(Births) AS total_chris_births
FROM names
WHERE Name='Chris'
GROUP BY State),

total_births AS(
SELECT State,SUM(Births) AS total_births
FROM names
GROUP BY State),

perc_rank AS(
SELECT *,DENSE_RANK() OVER(ORDER BY percentage DESC ) AS perc_rnk
FROM(
SELECT c.State,(total_chris_births/total_births)*100 AS percentage
FROM chris_names c
JOIN total_births t
ON c.State=t.State) AS t)

SELECT *
FROM perc_rank
WHERE perc_rnk=1
